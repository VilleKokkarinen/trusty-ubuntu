﻿﻿using System;
using System.Threading;

namespace CaseOpener
{
	class Gamble
	{
		private double CaseCost;
		private double WinValue;
		private string ItemName;
		private double PlayerMoney;
		private int Token;

		public Gamble() { }

		public Gamble(double Money, double Cost)
		{
			PlayerMoney = Money;
			CaseCost = Cost;
		}


		public void OpenCase()
		{
			var Case = new Case1 ();
			Case.RollNumber ();
			Token = Case.returnToken ();
			ItemName = Case.ReturnItemName ();
			WinValue = Case.ReturnWinValue ();
			SetPlayerMoney ();
			CountWin ();
		}



		private void SetPlayerMoney()
		{           
			PlayerMoney = PlayerMoney - CaseCost;
		}

		private void CountWin()
		{
			PlayerMoney = PlayerMoney + WinValue;
		}

		public double ReturnPlayerMoney()
		{
			return PlayerMoney;
		}
		public int returnToken()
		{
			return Token;
		}
		public string ReturnItemName()
		{
			return ItemName;
		}

		public double ReturnWinValue()
		{
			return WinValue;
		}
	

	}
}