﻿﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace CaseOpener
{
	class Program
	{
		//Total amount of players' Money as default
		static double Money = 1000.00;
		static string Name;
		static string ItemName;
		static double WinValue;
		static double CasePrice;
		static int token;




		public static void WriteConsole()
		{
			//Writes the stuff on console
			Console.SetCursorPosition(10, 7);
			Console.WriteLine("=================================="); Console.SetCursorPosition(10, 8);
			Console.WriteLine("|  Opened Case Name = " +Name +             "                     "); Console.SetCursorPosition(10, 9);
			Console.WriteLine("|  Money left = " +Math.Round(Money,2) +    "                     "); Console.SetCursorPosition(10, 10);
			Console.WriteLine("|  Skin Colour = " + ItemName+              "                     "); Console.SetCursorPosition(10, 11);
			Console.WriteLine("|  Skin Value = " + Math.Round(WinValue,2)+ "                     "); Console.SetCursorPosition(10, 12);
			Console.WriteLine("|  Rolled number = "+token+                 "                     "); Console.SetCursorPosition(10, 13);
			Console.WriteLine("==================================");

			//Makes cursor not visible for player
			Console.CursorVisible = false;


		}

		public static void GAMBLE()
		{
			//Sets a variable "Key" to read user input. In this case "The Spacebar" button
			ConsoleKeyInfo Key;
			Key = Console.ReadKey();

			while (Key.Key == ConsoleKey.Spacebar)
			{
				//If Money is equal to, or higher than Cases' Price allows to roll
				if (Money >= CasePrice)
				{
					//Creates a new gamble variable, Gives it the amount of money player has, and the cost of the case
					var gamble = new Gamble (Money, CasePrice);

					//Opens 1 case
					gamble.OpenCase ();

					//Returns the Roll number 1-100, it rolled
					token = gamble.returnToken ();

					//returns the Items' name Roll defined
					ItemName = gamble.ReturnItemName ();

					//Returns the Amount player won with the item
					WinValue = gamble.ReturnWinValue ();

					//returns the total amount of money player has left
					Money = gamble.ReturnPlayerMoney ();

					//Writes the info to console
					WriteConsole();

					//Reads a key input, before opening another one
					Console.ReadKey();
				}
				else
				{
					//If player had no money left, stops & inputs this text
					Console.WriteLine("Money left is not enough, Cant Roll");
					Console.ReadLine();
				}
			}
		}



		static void Main(string[] args)
		{
			//Creates a new case
			var Case = new Case1 ();
			//Gets the cases' Name & Cost from it's CS file
			Name = Case.ReturnCaseName ();
			CasePrice = Case.ReturnCaseCost ();

			Console.Title = Name;
			Console.WriteLine("" +
			"Rng based Loot software for RPG'S \n" +
			"Copyrights >> FREE SOFTWARE <<\n" +
			"GL & HF \n" +
			"Remember, gambling is not allowed for under 18-yo's\n" +
			"But hey who's there to check that anyways... ;)");	

				//Time to gamble
				GAMBLE();
				
				//Reads a line before exiting
				Console.ReadLine();

		}
	}
}