﻿using System;

namespace CaseOpener
{
	class Case1
	{		
		private string CaseName = "Case1";
		private double CaseCost = 2.25;
		private double WinValue;
		private string ItemName;
		private int Roll;

		public Case1() { }

		public int returnToken()
		{
			return Roll;
		}

		private void ROLL()
		{
			Random roll = new Random();
			Roll = roll.Next(0, 100);

			if (Roll < 1)
			{				
				YellowItem ();
			}
			if (Roll >= 2 && Roll <= 20)
			{
				PinkItem ();
			}
			if (Roll > 21 && Roll <= 55)
			{
				PurpleItem ();
			}
			if(Roll > 55)
			{
				BlueItem ();
			}
		}

		public void RollNumber()
		{ 
			ROLL ();
		}

		public string ReturnItemName()
		{
			return ItemName;
		}

		public double ReturnWinValue()
		{
			return WinValue;
		}

		public string ReturnCaseName()
		{
			return CaseName;
		}

		public double ReturnCaseCost()
		{
			return CaseCost;
		}

		private void BlueItem()
		{
			int Chance;
			int Enchanted;
			Random roll = new Random();
			Chance = roll.Next(0, 11);
			Enchanted = roll.Next (0, 11);

			if(Chance == 0)
			{
				ItemName = "Blue, Common";
				WinValue = 0.10;
			}
			if (Chance == 1)
			{
				ItemName = "Blue, Common";
				WinValue = 0.12;
			}
			if (Chance == 2)
			{
				ItemName = "Blue, Common";
				WinValue = 0.01;
			}
			if (Chance == 3)
			{
				ItemName = "Blue, Basic";
				WinValue = 0.01;
			}
			if (Chance == 4)
			{
				ItemName = "Blue, Basic";
				WinValue = 0.01;
			}
			if (Chance == 5)
			{
				ItemName = "Blue, Basic";
				WinValue = 0.06;
			}
			if (Chance == 6)
			{
				ItemName = "Blue, Basic";
				WinValue = 0.12;
			}
			if (Chance == 7)
			{
				ItemName = "Blue, Semi-rare";
				WinValue = 0.29;
			}
			if (Chance == 8)
			{
				ItemName = "Blue, Semi-rare";
				WinValue = 0.36;
			}
			if (Chance == 9)
			{
				ItemName = "Blue, Rare";
				WinValue = 0.45;
			}
			if (Chance == 10)
			{
				ItemName = "Blue, Ultra Rare";
				WinValue = 1.15;
			}
			if (Enchanted == 1) {
				ItemName = ItemName + " Enchanted";
				WinValue = WinValue + WinValue * roll.Next (0, 3);
			}
		}


		private void PurpleItem()
		{
			int Chance;
			int Enchanted;
			Random roll = new Random();
			Chance = roll.Next(0, 11);
			Enchanted = roll.Next (0, 11);

			if(Chance == 0)
			{
				ItemName = "Purple, Common";
				WinValue = 0.20;
			}
			if (Chance == 1)
			{
				ItemName = "Purple, Common";
				WinValue = 0.23;
			}
			if (Chance == 2)
			{
				ItemName = "Purple, Common";
				WinValue = 0.25;
			}
			if (Chance == 3)
			{
				ItemName = "Purple, Basic";
				WinValue = 0.42;
			}
			if (Chance == 4)
			{
				ItemName = "Purple, Basic";
				WinValue = 0.55;
			}
			if (Chance == 5)
			{
				ItemName = "Purple, Basic";
				WinValue = 0.65;
			}
			if (Chance == 6)
			{
				ItemName = "Purple, Basic";
				WinValue = 0.75;
			}
			if (Chance == 7)
			{
				ItemName = "Purple, Semi-rare";
				WinValue = 2;
			}
			if (Chance == 8)
			{
				ItemName = "Purple, Semi-rare";
				WinValue = 2.50;
			}
			if (Chance == 9)
			{
				ItemName = "Purple, Rare";
				WinValue = 5.60;
			}
			if (Chance == 10)
			{
				ItemName = "Purple, Ultra Rare";
				WinValue = 15.35;
			}
			if (Enchanted == 1) {
				ItemName = ItemName + " Enchanted";
				WinValue = WinValue + WinValue * roll.Next (0, 3);
			}
		}


		private void PinkItem()
		{
			int Chance;
			int Enchanted;
			Random roll = new Random();
			Chance = roll.Next(0, 11);
			Enchanted = roll.Next (0, 11);

			if(Chance == 0)
			{
				ItemName = "Pink, Common";
				WinValue = 1.95;
			}
			if (Chance == 1)
			{
				ItemName = "Pink, Common";
				WinValue = 2.15;
			}
			if (Chance == 2)
			{
				ItemName = "Pink, Common";
				WinValue = 2.25;
			}
			if (Chance == 3)
			{
				ItemName = "Pink, Basic";
				WinValue = 3.75;
			}
			if (Chance == 4)
			{
				ItemName = "Pink, Basic";
				WinValue = 4.25;
			}
			if (Chance == 5)
			{
				ItemName = "Pink, Basic";
				WinValue = 7.75;
			}
			if (Chance == 6)
			{
				ItemName = "Pink, Basic";
				WinValue = 8.77;
			}
			if (Chance == 7)
			{
				ItemName = "Pink, Semi-rare";
				WinValue = 14.50;
			}
			if (Chance == 8)
			{
				ItemName = "Pink, Semi-rare";
				WinValue = 15.50;
			}
			if (Chance == 9)
			{
				ItemName = "Pink, Rare";
				WinValue = 20.50;
			}
			if (Chance == 10)
			{
				ItemName = "Pink, Ultra Rare";
				WinValue = 45.50;
			}
			if (Enchanted == 1) {
				ItemName = ItemName + " Enchanted";
				WinValue = WinValue + WinValue * roll.Next (0, 3);
			}
		}



		private void YellowItem()
		{
			int Chance;
			int Enchanted;
			Random roll = new Random();
			Chance = roll.Next(0, 11);
			Enchanted = roll.Next (0, 11);


			if(Chance == 0)
			{
				ItemName = "Yellow, Common";
				WinValue = 35.50;
			}
			if (Chance == 1)
			{
				ItemName = "Yellow, Common";
				WinValue = 37.80;
			}
			if (Chance == 2)
			{
				ItemName = "Yellow, Common";
				WinValue = 40.2;
			}
			if (Chance == 3)
			{
				ItemName = "Yellow, Basic";
				WinValue = 42.05;
			}
			if (Chance == 4)
			{
				ItemName = "Yellow, Basic";
				WinValue = 44.05;
			}
			if (Chance == 5)
			{
				ItemName = "Yellow, Basic";
				WinValue = 45.10;
			}
			if (Chance == 6)
			{
				ItemName = "Yellow, Basic";
				WinValue = 46.25;
			}
			if (Chance == 7)
			{
				ItemName = "Yellow, Semi-rare";
				WinValue = 65.75;
			}
			if (Chance == 8)
			{
				ItemName = "Yellow, Semi-rare";
				WinValue = 72.75;
			}
			if (Chance == 9)
			{
				ItemName = "Yellow, Rare";
				WinValue = 120.50;
			}
			if (Chance == 10)
			{
				ItemName = "Yellow, Ultra Rare";
				WinValue = 250.50;
			}
			if (Enchanted == 1) {
				ItemName = ItemName + " Enchanted";
				WinValue = WinValue + WinValue * roll.Next (0, 3);
			}
		}



	}
} 