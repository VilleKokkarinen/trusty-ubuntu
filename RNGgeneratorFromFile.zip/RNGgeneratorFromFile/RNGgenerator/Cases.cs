﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.Specialized;
using System.Threading;

namespace CaseOpener
{
	class Case1
	{		
		private string CaseName;
		private double CaseCost;
		private double WinValue;
		private string ItemName;
		private int Roll;

		static Random roll = new Random();

		private List<string> ListOfItems = new List<string>();
		private List<string> ListOfColor_0_items = new List<string> ();
		private List<string> ListOfColor_1_items = new List<string> ();
		private List<string> ListOfColor_2_items = new List<string> ();
		private List<string> ListOfColor_3_items = new List<string> ();
		private List<string> ListOfColor_4_items = new List<string> ();

		private List<string> ListOfColor_0_items_chance = new List<string> ();
		private List<string> ListOfColor_1_items_chance = new List<string> ();
		private List<string> ListOfColor_2_items_chance = new List<string> ();
		private List<string> ListOfColor_3_items_chance = new List<string> ();
		private List<string> ListOfColor_4_items_chance = new List<string> ();

		public Case1() { }

		public int returnToken()
		{
			return Roll;

		}

		private void SplitItemsToGroupLists()
		{			
			

			for (int i = 0; i <= ListOfItems.Count; i++) {
				try{
				char Delimiter = ',';
				string[] Combined = ListOfItems[i].Split (Delimiter);
								
				int GroupID = int.Parse (Combined [0]);

				if (GroupID == 0) {
						ListOfColor_0_items.Add (Combined[1] + "," + Combined[2] +" "+ Combined[3] + "," + Combined[4]);
						ListOfColor_0_items_chance.Add(Combined[5]);
				}

				if (GroupID == 1) {
						ListOfColor_1_items.Add (Combined[1] + "," + Combined[2] +" "+ Combined[3] + "," + Combined[4]);
						ListOfColor_1_items_chance.Add(Combined[5]);
				}

				if (GroupID == 2) {
						ListOfColor_2_items.Add (Combined[1] + "," + Combined[2] +" "+ Combined[3] + "," + Combined[4]);
						ListOfColor_2_items_chance.Add(Combined[5]);
				}

				if (GroupID == 3) {
						ListOfColor_3_items.Add (Combined[1] + "," + Combined[2] +" "+ Combined[3] + "," + Combined[4]);
						ListOfColor_3_items_chance.Add(Combined[5]);
				}

				if (GroupID == 4) {
						ListOfColor_4_items.Add (Combined[1] + "," + Combined[2] +" "+ Combined[3] + "," + Combined[4]);
						ListOfColor_4_items_chance.Add(Combined[5]);
				}
				}catch(Exception){
				}

			}

		}

		private void ROLL(){
			
			int Rollgroup = roll.Next (0, 100);
			int RollItem = roll.Next (0, 100);
			int RollEnchant = roll.Next (0, 100);
			int itemchance = 0;

			string directory = AppDomain.CurrentDomain.BaseDirectory;
			string CaseFile	= directory + "/" +CaseName+".txt";
			string[]Groups= System.IO.File.ReadAllLines(CaseFile);
		
			char delimiter = '=';
			List<int> GroupChances = new List<int> ();
			List<string> GroupNames = new List<string> ();

			for (int i = 2; i <= 7; i++) {
				string[] Group = Groups [i].Split(delimiter);
				GroupNames.Add (Group[0]);
				GroupChances.Add (int.Parse((Group[1])));
			}

			if (Rollgroup <= GroupChances [4]) 
			{
				itemchance = itemchance + ListOfColor_0_items_chance[
				if (RollItem > 0 && RollItem <= itemchance) {

				}

			}

			if (Rollgroup <= GroupChances [3] && Rollgroup >= GroupChances[4]) 
			{


			}
			if (Rollgroup <= GroupChances [2] && Rollgroup >= GroupChances[3]) 
			{


			}
			if (Rollgroup <= GroupChances [1] && Rollgroup >= GroupChances[2]) 
			{


			}
			if (Rollgroup <= GroupChances [0] && Rollgroup >= GroupChances[1]) 
			{


			}



		}

		public void AddItemDetails()
		{
			List<string> CaseList = new List<string> ();
			List<string> ItemList = new List<string> ();
			List<string> ItemList2 = new List<string> ();


			string name = "";
			string Color = "";
			double value = 0;
			int chance = 0;
			int GroupID = 0;
			int i = 0;

			string directory = AppDomain.CurrentDomain.BaseDirectory;
			string CaseFile	= directory + "/" +"CASELIST.txt";
			string[]Cases= System.IO.File.ReadAllLines(CaseFile);
			string[]ItemS= System.IO.File.ReadAllLines(CaseFile);

			foreach (string Case in Cases) {
				CaseList.Add (Case);
			}

			foreach (string Case in CaseList) {
				CaseFile= directory + "/" +Case;
				ItemS= System.IO.File.ReadAllLines(CaseFile);
			}

			List<string> Items = ItemS.ToList ();
			CaseName = Items [0].Remove (0, 9);
			Items.RemoveRange (0, 9);

			foreach (string Item in Items) {

				if (Item != "") {
					char Delimiter = ';';
					string[] Combined = Item.Split (Delimiter);

					if (Combined.Length == 4) {
						Color = Combined [0];
						name = Combined [1];
						value = double.Parse (Combined [2]);
						chance = int.Parse (Combined [3]);
						ItemList.Add (i+","+Color + "," + name + "," + value+","+chance);
					}
					i++;
				}
			}

			for(int l = 0; l <= ItemList.Count; l ++){
				try{
				char Delimiter = ',';
				string[] Combined = ItemList[l].Split (Delimiter);
				string[] Combined2 = ItemList[l+1].Split (Delimiter);
					int ID = int.Parse(Combined[0]);

				Color = Combined [1];
				string Color2 = Combined2 [1];
				name = Combined [2];

				value = double.Parse (Combined [3]);
				chance = int.Parse (Combined [4]);



					ItemList2.Add(GroupID + "," + ID + "," + Color + "," + name + "," + value + "," + chance);

					if(Color2 == Color){						
					}else{
						GroupID++;
					}
				}catch(Exception){
				}

			}
			ItemList2.Add (GroupID + "," +ItemList [ItemList.Count-1]);
			ListOfItems = ItemList2;
		}

		public void RollNumber()
		{ 
			SplitItemsToGroupLists ();
			ROLL ();
		}

		public string ReturnItemName()
		{
			return ItemName;
		}

		public double ReturnWinValue()
		{
			return WinValue;
		}

		public string ReturnCaseName()
		{
			return CaseName;
		}

		public double ReturnCaseCost()
		{
			return CaseCost;
		}

		public void Null()
		{
			ItemName = "";
			WinValue = 0;
		}



	}
} 