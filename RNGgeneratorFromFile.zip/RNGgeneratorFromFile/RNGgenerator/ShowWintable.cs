﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Threading;
//using System.Collections.Specialized;
//using System.Text.RegularExpressions;
//
//namespace CaseOpener
//{
//	public class ShowWintable
//	{
//		public static void Wintable()
//		{
//			Show ();
//		}
//
//		private static void Show ()
//		{
//			var Case = new Case1 ();
//
//			Case.AddItemDetails ();
//			OrderedDictionary ItemDetails = new OrderedDictionary ();
//			ItemDetails = Case.ReturnDictionary ();
//
//			ICollection keyCollection = ItemDetails.Keys;
//			ICollection valueCollection = ItemDetails.Values;
//			int dictionarySize = ItemDetails.Count;
//
//			String[] myKeys = new String[dictionarySize];
//			String[] myValues = new String[dictionarySize];
//			keyCollection.CopyTo(myKeys, 0);
//			valueCollection.CopyTo(myValues, 0);
//			string withNumbers;
//			string withoutNumbers;
//
//
//			List<string> CaseList = new List<string> ();
//			List<string> ItemNames = new List<string> ();
//			List<double> ItemValues = new List<double> ();
//			ItemValues.Add (0.10);
//			ItemValues.Add (0.12);
//			ItemValues.Add (0.01);
//			ItemValues.Add (0.01);
//			ItemValues.Add (0.01);
//			ItemValues.Add (0.06);
//			ItemValues.Add (0.12);
//			ItemValues.Add (0.29);
//			ItemValues.Add (0.36);
//			ItemValues.Add (0.45);
//			ItemValues.Add (1.15);
//			ItemValues.Add (0.13);
//			ItemValues.Add (0.15);
//			ItemValues.Add (0.18);
//			ItemValues.Add (0.24);
//			ItemValues.Add (0.36);
//			ItemValues.Add (0.40);
//			ItemValues.Add (0.44);
//			ItemValues.Add (0.66);
//			ItemValues.Add (0.75);
//			ItemValues.Add (1.05);
//			ItemValues.Add (6.35);
//			ItemValues.Add (1.12);
//			ItemValues.Add (1.25);
//			ItemValues.Add (1.35);
//			ItemValues.Add (1.45);
//			ItemValues.Add (1.67);
//			ItemValues.Add (1.75);
//			ItemValues.Add (1.86);
//			ItemValues.Add (5.65);
//			ItemValues.Add (6.24);
//			ItemValues.Add (12.50);
//			ItemValues.Add (23.23);
//			ItemValues.Add (1.15);
//			ItemValues.Add (1.45);
//			ItemValues.Add (2.50);
//			ItemValues.Add (2.75);
//			ItemValues.Add (3.05);
//			ItemValues.Add (3.25);
//			ItemValues.Add (3.50);
//			ItemValues.Add (12.40);
//			ItemValues.Add (17.22);
//			ItemValues.Add (30.60);
//			ItemValues.Add (45.55);
//			ItemValues.Add (38.55);
//			ItemValues.Add (45.55);
//			ItemValues.Add (52.05);
//			ItemValues.Add (55.55);
//			ItemValues.Add (58.33);
//			ItemValues.Add (60.24);
//			ItemValues.Add (65.25);
//			ItemValues.Add (78.15);
//			ItemValues.Add (100.14);
//			ItemValues.Add (150.00);
//			ItemValues.Add (222.50);
//
//			string file = "";
//
//			for (int i = 0; i < dictionarySize; i++)
//			{				
//				withNumbers = myKeys [i];
//				withoutNumbers = Regex.Replace(withNumbers, "[0-9]", "");
//				CaseList.Add (withoutNumbers);
//				ItemNames.Add (myValues [i]);
//
//				Console.WriteLine("{1,-10} {2}",i, withoutNumbers, myValues[i]);
//				file = file + withoutNumbers + ";" + myValues [i] +";"+ItemValues[i] + Environment.NewLine;
//				try{
//					if (withoutNumbers != Regex.Replace(myKeys[i+1], "[0-9]", "")) {
//						Console.WriteLine ();
//						file = file + Environment.NewLine;
//					}
//				}catch(Exception){
//				}
//
//			}
//
//			System.IO.File.WriteAllText("/home/ecomond/Desktop/stuff.txt",file);
//
//
//			for (int i = 0; i < CaseList.Count; i++) {
//				
//			}
//
//				
//		Console.WriteLine ("==================================");
////				Console.WriteLine ("Case Name = " + Case_Name);
////				Console.WriteLine ("Case Item_1 Name = " + Item_1_Name + "|" + "Item_1 Value = " + Item_1_Value);
////				Console.WriteLine ("Case Item_2 Name = " + Item_2_Name + "|" + "Item_2 Value = " + Item_2_Value);
//
//				//Repeat till no more
//				//Maybe For loop / while loop ->|<-
//				//!Case item amounts might vary (?)!
//
//				Console.WriteLine ("==================================");
//				Console.WriteLine ();
//				Console.WriteLine ();
//
//			ItemNames.Clear ();
//			ItemValues.Clear ();
//
//			//Go back to main method @ userinputconsole.cs
//
//
//		}
//	}
//}