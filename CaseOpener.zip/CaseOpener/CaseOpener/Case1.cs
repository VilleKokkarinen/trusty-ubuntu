﻿using System;

namespace CaseOpener
{
    class Case1
    {
        private string CaseName;
        private double CaseCost;
        private double PlayerMoney;
        private double WinValue;
        private string ItemName;
        private int Roll = 0;
       
        public Case1() { }
       
        public Case1(string Name, double Cost)
        {
            CaseName = Name;
            CaseCost = Cost;           
        }

        public void BlueItem()
        {
            int Chance;
            Random roll = new Random();
            Chance = roll.Next(0, 11);

            if(Chance == 0)
            {
                ItemName = "Blue, Basic Sword";
                WinValue = 0.10;
            }
            if (Chance == 1)
            {
                ItemName = "Blue, Basic ShortSword";
                WinValue = 0.12;
            }
            if (Chance == 2)
            {
                ItemName = "Blue, Basic LongSword";
                WinValue = 0.01;
            }
            if (Chance == 3)
            {
                ItemName = "Blue, Basic Shortbow";
                WinValue = 0.01;
            }
            if (Chance == 4)
            {
                ItemName = "Blue, Basic Longbow";
                WinValue = 0.01;
            }
            if (Chance == 5)
            {
                ItemName = "Blue, Basic Crossbow";
                WinValue = 0.06;
            }
            if (Chance == 6)
            {
                ItemName = "Blue, Basic 2 Handed sword";
                WinValue = 0.12;
            }
            if (Chance == 7)
            {
                ItemName = "Blue, Basic Halberd";
                WinValue = 0.09;
            }
            if (Chance == 8)
            {
                ItemName = "Blue, Basic Roundshield";
                WinValue = 0.06;
            }
            if (Chance == 9)
            {
                ItemName = "Blue, Basic Squareshield";
                WinValue = 0.08;
            }
            if (Chance == 10)
            {
                ItemName = "Blue, Basic Rare Item";
                WinValue = 0.23;
            }
        }
        public void PurpleItem()
        {
            int Chance;
            Random roll = new Random();
            Chance = roll.Next(0, 11);

            if (Chance == 0)
            {
                ItemName = "Purple, Basic Sword";
                WinValue = 0.10;
            }
            if (Chance == 1)
            {
                ItemName = "Purple, Basic ShortSword";
                WinValue = 0.12;
            }
            if (Chance == 2)
            {
                ItemName = "Purple, Basic LongSword";
                WinValue = 0.01;
            }
            if (Chance == 3)
            {
                ItemName = "Purple, Basic Shortbow";
                WinValue = 0.01;
            }
            if (Chance == 4)
            {
                ItemName = "Purple, Basic Longbow";
                WinValue = 0.01;
            }
            if (Chance == 5)
            {
                ItemName = "Purple, Basic Crossbow";
                WinValue = 0.06;
            }
            if (Chance == 6)
            {
                ItemName = "Purple, Basic 2 Handed sword";
                WinValue = 0.12;
            }
            if (Chance == 7)
            {
                ItemName = "Purple, Basic Halberd";
                WinValue = 0.09;
            }
            if (Chance == 8)
            {
                ItemName = "Purple, Basic Roundshield";
                WinValue = 0.06;
            }
            if (Chance == 9)
            {
                ItemName = "Purple, Basic Squareshield";
                WinValue = 0.08;
            }
            if (Chance == 10)
            {
                ItemName = "Purple, Basic Rare Item";
                WinValue = 0.23;
            }
        }
        public void PinkItem()
        {
            ItemName = "Pink";
            WinValue = 3.50;
        }
        public void Knife()
        {
            ItemName = "Knife";
            WinValue = 100.00;
        }       


        public void SetPlayerData(String Name, Double Cost, Double Money)
        {
            CaseName = Name;
            CaseCost = Cost;
            PlayerMoney = Money;
        }

        public void RollNumber()
        {           
            PlayerMoney = PlayerMoney - CaseCost;

            Random roll = new Random();
            Roll = roll.Next(0, 100);
            
            if (Roll < 1)
            {
                Knife();
            }
            if (Roll >= 2 && Roll <= 12)
            {
                PinkItem();
            }
            if (Roll > 12 && Roll <= 37)
            {
                PurpleItem();
            }
            if(Roll > 38)
            {
                BlueItem();
            } 
        }

        public void CountWin()
        {
            PlayerMoney = PlayerMoney + WinValue;
        }

        public double ReturnWin()
        {
            return PlayerMoney;
        }
        public double ReturnWinValue()
        {
            return WinValue;
        }
        public string ReturnItemName()
        {
            return ItemName;
        }
        public string ReturnToken()
        {
            return Roll.ToString();   
        }

        public void ReturnCaseName(ref string Name)
        {
            Name = CaseName;
        }

    }
}