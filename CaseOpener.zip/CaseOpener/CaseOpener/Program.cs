﻿using System;
using System.Collections.Generic;

namespace CaseOpener
{
    class Program
    {
        static Double Money = 1000.00;
        static Double CasePrice = 2.25;
        static string Name = "Best";

        static Case1 Case = new Case1();

        public static void WriteConsole()
        {
            string itemname;
            itemname = Case.ReturnItemName();

            string token;
            token = Case.ReturnToken();

            double Winvalue;
            Winvalue = Case.ReturnWinValue();

            string money = Money.ToString();
            string money1 = "";
            string money2 = "";
            char Delimiter = ',';
            string[] moneyarray = money.Split(Delimiter);
            List<string> moneylist = new List<string>();
            foreach (string moneys in moneyarray)
            {
                moneylist.Add(moneys);
            }
            money1 = moneylist[0];

            if(moneylist.Count == 1) { moneylist.Add("00");}
            if(moneylist[1].Length < 2) { moneylist[1] = moneylist[1] + "0"; }
            money2 = "," + moneylist[1].Substring(0,2);
            money = money1 + money2;

            Console.SetCursorPosition(10, 7);
            Console.WriteLine("=================================="); Console.SetCursorPosition(10, 8);
            Console.WriteLine("|  Opened Case Name = " +Name +             "   "); Console.SetCursorPosition(10, 9);
            Console.WriteLine("|  Money left = " +money+                   "   "); Console.SetCursorPosition(10, 10);
            Console.WriteLine("|  Skin Colour = " + itemname+              "   "); Console.SetCursorPosition(10, 11);
            Console.WriteLine("|  Skin Value = " + Winvalue.ToString()+    "   "); Console.SetCursorPosition(10, 12);
            Console.WriteLine("|  Rolled number = "+token+                 "   "); Console.SetCursorPosition(10, 13);
            Console.WriteLine("==================================");

            
            Console.SetCursorPosition(43, 8);
            Console.Write("|");
            Console.SetCursorPosition(43, 9);
            Console.Write("|");
            Console.SetCursorPosition(43, 10);
            Console.Write("|");
            Console.SetCursorPosition(43, 11);
            Console.Write("|");
            Console.SetCursorPosition(43, 12);
            Console.Write("|");
            Console.SetCursorPosition(30, 0);
            Console.CursorVisible = false;


        }

        public static void CreateCase1()
        {            
            Case.SetPlayerData(Name, CasePrice, Money);
        }

        public static void GAMBLE()
        {
            ConsoleKeyInfo Key;
            Key = Console.ReadKey();

            while (Key.Key == ConsoleKey.Spacebar)
            {
                if (Money >= CasePrice)
                {
                    Case.RollNumber();
                    Case.CountWin();
                    Money = Case.ReturnWin();
                    WriteConsole();
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("MONEY IS NOT ENOUGH, Stopping");
                    Console.ReadLine();
                }
            }

        }



        static void Main(string[] args)
        {
            Console.Title = Name + "Case";
            Console.WriteLine("" +
                "Gambling stuff boi\n" +
                "Copyrights ownt By the amazing YA BOII\n" +
                "I hope you enjoy my software \n" +
                "Remember, gambling is not allowed for under 18-yo's");

            CreateCase1();
        
            GAMBLE();

            Console.ReadLine();

        }
    }
}