﻿using Engine;
using System;
using System.ComponentModel;
using System.IO;
using System.Linq;

namespace Application
{
    public class Console
    {
        private const string PLAYER_DATA_FILE_NAME = "PlayerData.xml";

        private static Player _player;

        private static void Main(string[] args)
        {
            // Load the player
            LoadGameData();

            System.Console.WriteLine("Type 'Help' to see a list of commands");
            System.Console.WriteLine("");

            DisplayCurrentLocation();

            // Connect player events to functions that will display in the UI
            _player.PropertyChanged += Player_OnPropertyChanged;
            _player.OnMessage += Player_OnMessage;

            // Infinite loop, until the user types "exit"
            while (true)
            {
                // Display a prompt, so the user knows to type something
                System.Console.Write(">");

                // Wait for the user to type something, and press the <Enter> key
                string userInput = System.Console.ReadLine();

                // If they typed a blank line, loop back and wait for input again
                if (string.IsNullOrWhiteSpace(userInput))
                {
                    continue;
                }

                // Convert to lower-case, to make comparisons easier
                string cleanedInput = userInput.ToLower();

                // Save the current game data, and break out of the "while(true)" loop
                if (cleanedInput == "exit")
                {
                    SaveGameData();

                    break;
                }

                // If the user typed something, try to determine what to do
                ParseInput(cleanedInput);
            }
        }

        private static void Player_OnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "CurrentLocation")
            {
                DisplayCurrentLocation();

                if (_player.CurrentLocation.VendorWorkingHere != null)
                {
                    System.Console.WriteLine("You see a vendor here: {0}", _player.CurrentLocation.VendorWorkingHere.Name);
                }
            }
        }

        private static void Player_OnMessage(object sender, MessageEventArgs e)
        {
            System.Console.WriteLine(e.Message);

            if (e.AddExtraNewLine)
            {
                System.Console.WriteLine("");
            }
        }

        private static void ParseInput(string input)
        {
            if (input.Contains("help") || input == "?")
            {
                System.Console.WriteLine("Available commands");
                System.Console.WriteLine("====================================");
                System.Console.WriteLine("Stats - Display player information");
                System.Console.WriteLine("Look - Get the description of your location");
                System.Console.WriteLine("Inventory - Display your inventory");
                System.Console.WriteLine("Quests - Display your quests");
                System.Console.WriteLine("Attack - Fight the monster");
                System.Console.WriteLine("Equip <weapon name> - Set your current weapon");
                System.Console.WriteLine("Drink <potion name> - Drink a potion");
                System.Console.WriteLine("Trade - display your inventory and vendor's inventory");
                System.Console.WriteLine("Buy <item name> - Buy an item from a vendor");
                System.Console.WriteLine("Sell <item name> - Sell an item to a vendor");
                System.Console.WriteLine("North - Move North");
                System.Console.WriteLine("South - Move South");
                System.Console.WriteLine("East - Move East");
                System.Console.WriteLine("West - Move West");
                System.Console.WriteLine("Exit - Save the game and exit");
            }
            else if (input == "stats")
            {
                System.Console.WriteLine("Current hit points: {0}", _player.CurrentHitPoints);
                System.Console.WriteLine("Maximum hit points: {0}", _player.MaximumHitPoints);
                System.Console.WriteLine("Experience Points: {0}", _player.ExperiencePoints);
                System.Console.WriteLine("Level: {0}", _player.Level);
                System.Console.WriteLine("Gold: {0}", _player.Gold);
            }
            else if (input == "look")
            {
                DisplayCurrentLocation();
            }
            else if (input.Contains("north"))
            {
                if (_player.CurrentLocation.LocationToNorth == null)
                {
                    System.Console.WriteLine("You cannot move North");
                }
                else
                {
                    _player.MoveNorth();
                }
            }
            else if (input.Contains("east"))
            {
                if (_player.CurrentLocation.LocationToEast == null)
                {
                    System.Console.WriteLine("You cannot move East");
                }
                else
                {
                    _player.MoveEast();
                }
            }
            else if (input.Contains("south"))
            {
                if (_player.CurrentLocation.LocationToSouth == null)
                {
                    System.Console.WriteLine("You cannot move South");
                }
                else
                {
                    _player.MoveSouth();
                }
            }
            else if (input.Contains("west"))
            {
                if (_player.CurrentLocation.LocationToWest == null)
                {
                    System.Console.WriteLine("You cannot move West");
                }
                else
                {
                    _player.MoveWest();
                }
            }
            else if (input == "inventory")
            {
                foreach (InventoryItem inventoryItem in _player.Inventory)
                {
                    System.Console.WriteLine("{0}: {1}", inventoryItem.Description, inventoryItem.Quantity);
                }
            }
            else if (input == "quests")
            {
                if (_player.Quests.Count == 0)
                {
                    System.Console.WriteLine("You do not have any quests");
                }
                else
                {
                    foreach (PlayerQuest playerQuest in _player.Quests)
                    {
                        System.Console.WriteLine("{0}: {1}", playerQuest.Name,
                            playerQuest.IsCompleted ? "Completed" : "Incomplete");
                    }
                }
            }
            else if (input.Contains("attack"))
            {
                if (!_player.CurrentLocation.HasAMonster)
                {
                    System.Console.WriteLine("You're attacking air");
                }
                else
                {
                    if (_player.CurrentWeapon == null)
                    {
                        // Select the first weapon in the player's inventory 
                        // (or 'null', if they do not have any weapons)
                        _player.CurrentWeapon = _player.Weapons.FirstOrDefault();
                    }

                    if (_player.CurrentWeapon == null)
                    {
                        System.Console.WriteLine("You do not have any weapons");
                    }
                    else
                    {
                        _player.UseWeapon(_player.CurrentWeapon);
                    }
                }
            }
            else if (input.StartsWith("equip "))
            {
                string inputWeaponName = input.Substring(6).Trim();

                if (string.IsNullOrEmpty(inputWeaponName))
                {
                    System.Console.WriteLine("You must enter the name of the weapon to equip");
                }
                else
                {
                    Weapon weaponToEquip =
                        _player.Weapons.SingleOrDefault(
                            x => x.Name.ToLower() == inputWeaponName || x.NamePlural.ToLower() == inputWeaponName);

                    if (weaponToEquip == null)
                    {
                        System.Console.WriteLine("You do not have the weapon: {0}", inputWeaponName);
                    }
                    else
                    {
                        _player.CurrentWeapon = weaponToEquip;

                        System.Console.WriteLine("You equip your {0}", _player.CurrentWeapon.Name);
                    }
                }
            }
            else if (input.StartsWith("drink "))
            {
                string inputPotionName = input.Substring(6).Trim();

                if (string.IsNullOrEmpty(inputPotionName))
                {
                    System.Console.WriteLine("You must enter the name of the potion to drink");
                }
                else
                {
                    HealingPotion potionToDrink =
                        _player.Potions.SingleOrDefault(
                            x => x.Name.ToLower() == inputPotionName || x.NamePlural.ToLower() == inputPotionName);

                    if (potionToDrink == null)
                    {
                        System.Console.WriteLine("You do not have the potion: {0}", inputPotionName);
                    }
                    else
                    {
                        _player.UsePotion(potionToDrink);
                    }
                }
            }
            else if (input == "trade")
            {
                if (_player.CurrentLocation.VendorWorkingHere == null)
                {
                    System.Console.WriteLine("There is no vendor here");
                }
                else
                {
                    System.Console.WriteLine("PLAYER INVENTORY");
                    System.Console.WriteLine("================");

                    if (_player.Inventory.Count(x => x.Price != World.UNSELLABLE_ITEM_PRICE) == 0)
                    {
                        System.Console.WriteLine("You do not have any inventory");
                    }
                    else
                    {
                        foreach (
                            InventoryItem inventoryItem in _player.Inventory.Where(x => x.Price != World.UNSELLABLE_ITEM_PRICE))
                        {
                            System.Console.WriteLine("{0} {1} Price: {2}", inventoryItem.Quantity, inventoryItem.Description,
                                inventoryItem.Price);
                        }
                    }

                    System.Console.WriteLine("");
                    System.Console.WriteLine("VENDOR INVENTORY");
                    System.Console.WriteLine("================");

                    if (_player.CurrentLocation.VendorWorkingHere.Inventory.Count == 0)
                    {
                        System.Console.WriteLine("The vendor does not have any inventory");
                    }
                    else
                    {
                        foreach (InventoryItem inventoryItem in _player.CurrentLocation.VendorWorkingHere.Inventory)
                        {
                            System.Console.WriteLine("{0} {1} Price: {2}", inventoryItem.Quantity, inventoryItem.Description,
                                inventoryItem.Price);
                        }
                    }
                }
            }
            else if (input.StartsWith("buy "))
            {
                if (_player.CurrentLocation.VendorWorkingHere == null)
                {
                    System.Console.WriteLine("There is no vendor at this location");
                }
                else
                {
                    string itemName = input.Substring(4).Trim();

                    if (string.IsNullOrEmpty(itemName))
                    {
                        System.Console.WriteLine("You must enter the name of the item to buy");
                    }
                    else
                    {
                        // Get the InventoryItem from the trader's inventory
                        InventoryItem itemToBuy =
                            _player.CurrentLocation.VendorWorkingHere.Inventory.SingleOrDefault(
                                x => x.Details.Name.ToLower() == itemName);

                        // Check if the vendor has the item
                        if (itemToBuy == null)
                        {
                            System.Console.WriteLine("The vendor does not have any {0}", itemName);
                        }
                        else
                        {
                            // Check if the player has enough gold to buy the item
                            if (_player.Gold < itemToBuy.Price)
                            {
                                System.Console.WriteLine("You do not have enough gold to buy a {0}", itemToBuy.Description);
                            }
                            else
                            {
                                // Success! Buy the item
                                _player.AddItemToInventory(itemToBuy.Details);
                                _player.Gold -= itemToBuy.Price;

                                System.Console.WriteLine("You bought one {0} for {1} gold", itemToBuy.Details.Name, itemToBuy.Price);
                            }
                        }
                    }
                }
            }
            else if (input.StartsWith("sell "))
            {
                if (_player.CurrentLocation.VendorWorkingHere == null)
                {
                    System.Console.WriteLine("There is no vendor at this location");
                }
                else
                {
                    string itemName = input.Substring(5).Trim();

                    if (string.IsNullOrEmpty(itemName))
                    {
                        System.Console.WriteLine("You must enter the name of the item to sell");
                    }
                    else
                    {
                        // Get the InventoryItem from the player's inventory
                        InventoryItem itemToSell =
                            _player.Inventory.SingleOrDefault(x => x.Details.Name.ToLower() == itemName &&
                                                                   x.Quantity > 0 &&
                                                                   x.Price != World.UNSELLABLE_ITEM_PRICE);

                        // Check if the player has the item entered
                        if (itemToSell == null)
                        {
                            System.Console.WriteLine("The player cannot sell any {0}", itemName);
                        }
                        else
                        {
                            // Sell the item
                            _player.RemoveItemFromInventory(itemToSell.Details);
                            _player.Gold += itemToSell.Price;

                            System.Console.WriteLine("You receive {0} gold for your {1}", itemToSell.Price, itemToSell.Details.Name);
                        }
                    }
                }
            }
            else
            {
                System.Console.WriteLine("I do not understand");
                System.Console.WriteLine("Type 'Help' to see a list of available commands");
            }            
            System.Console.WriteLine("");
        }

        private static void DisplayCurrentLocation()
        {
            System.Console.WriteLine("You are at: {0}", _player.CurrentLocation.Name);

            if (_player.CurrentLocation.Description != "")
            {
                System.Console.WriteLine(_player.CurrentLocation.Description);
            }
        }

        private static void LoadGameData()
        {
            _player = PlayerDataMapper.CreateFromDatabase();

            if (_player == null)
            {
                if (File.Exists(PLAYER_DATA_FILE_NAME))
                {
                    _player = Player.CreatePlayerFromXmlString(File.ReadAllText(PLAYER_DATA_FILE_NAME));
                }
                else
                {
                    _player = Player.CreateDefaultPlayer();
                }
            }
        }

        private static void SaveGameData()
        {
            File.WriteAllText(PLAYER_DATA_FILE_NAME, _player.ToXmlString());

            PlayerDataMapper.SaveToDatabase(_player);
        }
    }
}